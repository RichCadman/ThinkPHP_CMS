<?php
/**
 * Created by PhpStorm.
 * ThinkPHP VERSIONS：Think PHP 5.1.5
 * Author: Mr.liu <417626953@qq.com>
 * Date: 2018/6/13
 * Time: 9:21
 */

namespace app\common\model;
use think\Model;

class System extends Model
{

}