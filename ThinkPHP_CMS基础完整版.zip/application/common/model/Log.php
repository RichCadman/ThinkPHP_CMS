<?php
/**
 * Created by PhpStorm.
 * ThinkPHP VERSIONS：Think PHP 5.1.5
 * Author: Mr.liu <417626953@qq.com>
 * Date: 2018/6/7
 * Time: 15:52
 */

namespace app\common\model;
use think\Model;

class Log extends Model
{

}