<?php
/**
 * Created by PhpStorm.
 * ThinkPHP VERSIONS：Think PHP 5.1.5
 * Author: Mr.liu <417626953@qq.com>
 * Date: 2018/6/21
 * Time: 13:07
 */

namespace app\common\model;
use think\Model;

class Comment extends Model
{

}