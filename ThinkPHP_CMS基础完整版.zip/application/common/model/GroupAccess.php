<?php
/**
 * Created by PhpStorm.
 * User: Mr.liu
 * Date: 2018/6/10
 * Time: 17:19
 */

namespace app\common\model;
use think\Model;
class GroupAccess extends Model
{

}