<?php
return[
    //操作
    'add'                               =>  '添加',
    'editor'                            =>  '编辑',
    'del'                               =>  '删除',
    'back'                              =>  '返回上层',
    'detail'                            =>  '详情',
    'comment'                           =>  '评论',
    'no_check'                          =>  '未审核',
    'check_success'                     =>  '审核通过',

    //后台header
    'go_home'                           =>  '前台访问',
    'clear_cache'                       =>  '清除缓存',
    'admin'                             =>  '管理员',
    'message'                           =>  '系统消息',
    'reload'                            =>  '刷新页面',
    'restore'                           =>  '一键还原',
    'login_out'                         =>  '安全退出',
    'icon'                              =>  '系统图标',
    'backups'                           =>  '数据备份',
    'database_restore'                  =>  '还原',
    'download'                          =>  '下载',
    'clear_logs'                        =>  '清空日志',
];
