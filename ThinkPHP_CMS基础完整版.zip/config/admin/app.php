<?php
//配置文件
return [
// URL伪静态后缀
    'url_html_suffix'        => '',
];