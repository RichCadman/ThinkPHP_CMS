<?php
//配置文件
return [
    //分页配置
    'type'      => 'page\Page',//分页类
    'var_page'  => 'page',
    'list_rows' => 10,

];