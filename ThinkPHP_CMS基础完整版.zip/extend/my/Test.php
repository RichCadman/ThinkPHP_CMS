<?php
namespace my;
/**
 * Created by PhpStorm.
 * ThinkPHP VERSIONS：Think PHP 5.1.5
 * Author: Mr.liu <417626953@qq.com>
 * Date: 2018/5/25
 * Time: 11:47
 */
//测试类
class Test
{
    //测试方法
    public function sayHello()
    {
        echo 'Hello World!';
    }
}